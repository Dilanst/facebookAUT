package co.facebook.ral.DTO;

public class DataDTO {

	private String partida;
	private String llegada;
	private String lugarPartida;
	private String lugarLlegada;
	
	public String getPartida() {
		return partida;
	}
	public void setPartida(String partida) {
		this.partida = partida;
	}
	public String getLlegada() {
		return llegada;
	}
	public void setLlegada(String llegada) {
		this.llegada = llegada;
	}
	public String getLugarLlegada() {
		return lugarLlegada;
	}
	public void setLugarLlegada(String lugarLlegada) {
		this.lugarLlegada = lugarLlegada;
	}
	public String getLugarPartida() {
		return lugarPartida;
	}
	public void setLugarPartida(String lugarPartida) {
		this.lugarPartida = lugarPartida;
	}
	
}
