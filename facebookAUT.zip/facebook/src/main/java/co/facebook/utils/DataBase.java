package co.facebook.utils;

public class DataBase {
	private String nameConection;
	private String descriptionDB;
	private String conection;
	public String getNameConection() {
		return nameConection;
	}
	public void setNameConection(String nameConection) {
		this.nameConection = nameConection;
	}
	public String getDescriptionDB() {
		return descriptionDB;
	}
	public void setDescriptionDB(String descriptionDB) {
		this.descriptionDB = descriptionDB;
	}
	public String getConection() {
		return conection;
	}
	public void setConection(String conection) {
		this.conection = conection;
	}
}
