package co.facebook.utils;

public class PATH {
	public static final TipoDriver NAVEGADOR = TipoDriver.CHROME;
	public static final String URL = "https://www.facebook.com/";
}
