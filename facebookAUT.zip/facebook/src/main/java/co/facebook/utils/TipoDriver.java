package co.facebook.utils;

public enum TipoDriver {
    CHROME,
    FIREFOX,
    IE,
    SAFARI;
}