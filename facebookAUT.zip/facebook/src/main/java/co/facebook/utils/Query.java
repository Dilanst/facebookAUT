package co.facebook.utils;

public class Query {
	private String nameQuery;
	private String descriptionQuery;
	private String query;
	public String getNameQuery() {
		return nameQuery;
	}
	public void setNameQuery(String nameQuery) {
		this.nameQuery = nameQuery;
	}
	public String getDescriptionQuery() {
		return descriptionQuery;
	}
	public void setDescriptionQuery(String descriptionQuery) {
		this.descriptionQuery = descriptionQuery;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
}